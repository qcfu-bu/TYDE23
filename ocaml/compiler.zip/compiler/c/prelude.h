#ifndef prelude_h

#define Ascii_c 16
#define EmptyString_c 17
#define String_c 18
#define box_intro_c 15
#define cons_c 9
#define ex_intro_c 12
#define false_c 3
#define le_refl_c 19
#define le_succ_c 20
#define nil_c 8
#define none_c 6
#define refl_c 21
#define sig_intro_c 13
#define some_c 7
#define succ_c 5
#define tnsr_intro_c 14
#define true_c 2
#define tt_c 1
#define vcons_c 11
#define vnil_c 10
#define zero_c 4

#endif